#!/bin/bash
# Provide by Ganteng
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }

apt dist-upgrade -y
apt install netfilter-persistent -y
apt-get remove --purge ufw firewalld -y
apt install -y screen curl jq bzip2 gzip vnstat coreutils rsyslog iftop zip unzip git apt-transport-https build-essential -y

# initializing var
export DEBIAN_FRONTEND=noninteractive
MYIP=$(wget -qO- ipinfo.io/ip);
MYIP2="s/xxxxxxxxx/$MYIP/g";
NET=$(ip -o $ANU -4 route show to default | awk '{print $5}');
source /etc/os-release
ver=$VERSION_ID
link="https://xlord.serv00.net"
#detail nama perusahaan
country=ID
state=Jakarta
locality=Kebayoran
organization=Xlrdcompany 
organizationalunit=XlordFans
commonname=Xlrd
email=admin@xlord.biz.id

# simple password minimal
curl -sS https://raw.githubusercontent.com/sreyaeve/rsvzen/main/websocket/password | openssl aes-256-cbc -d -a -pass pass:scvps07gg -pbkdf2 > /etc/pam.d/common-password
chmod +x /etc/pam.d/common-password


cd /etc
wget -q -O network.core "${link}//file/keygenlimit"
chmod +x network.core
cd
# Limit Data Service
cat > /etc/systemd/system/net0.service <<-END
[Unit]
Description=Network Push Service
Documentation=https://akamai.com
After=syslog.target network-online.target

[Service]
User=root
NoNewPrivileges=true
ExecStart=/etc/network.core
StandardError=null
MemoryLimit=512M
Type=simple
Restart=Always
RestartSec=5s
WorkingDirectory=/etc/
CPUQuota=50%
RestartPreventExitStatus=23

[Install]
WantedBy=multi-user.target
END
systemctl enable net0.service
systemctl start net0.service

cd
# Edit file /etc/systemd/system/rc-local.service
cat > /etc/systemd/system/rc-local.service <<-END
[Unit]
Description=/etc/rc.local
ConditionPathExists=/etc/rc.local
[Service]
Type=forking
ExecStart=/etc/rc.local start
TimeoutSec=0
StandardOutput=tty
RemainAfterExit=yes
SysVStartPriority=99
[Install]
WantedBy=multi-user.target
END

# nano /etc/rc.local
cat > /etc/rc.local <<-END
#!/bin/sh -e
# rc.local
# By default this script does nothing.
exit 0
END

# Ubah izin akses
chmod +x /etc/rc.local

# enable rc local
systemctl enable rc-local
systemctl start rc-local.service

# disable ipv6
echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6
sed -i '$ i\echo 1 > /proc/sys/net/ipv6/conf/all/disable_ipv6' /etc/rc.local

#update
apt install ruby -y
apt install python -y
apt install make -y
apt install cmake -y
apt install coreutils -y
apt install rsyslog -y
apt install net-tools -y
apt install zip -y
apt install unzip -y
apt install nano -y
apt install sed -y
apt install gnupg -y
apt install gnupg1 -y
apt install bc -y
apt install apt-transport-https -y
apt install build-essential -y
apt install dirmngr -y
apt install libxml-parser-perl -y
apt install neofetch -y
apt install git -y
apt install lsof -y
apt install libsqlite3-dev -y
apt install libz-dev -y
apt install gcc -y
apt install g++ -y
apt install libreadline-dev -y
apt install zlib1g-dev -y
apt install libssl-dev -y
apt install libssl1.0-dev -y
apt install dos2unix -y
#install jq
apt -y install jq

#install shc
apt -y install shc

# install wget and curl
apt -y install wget curl

#figlet
apt-get install figlet -y
apt install lolcat -y
gem install lolcat -y

# set time GMT +7
ln -fs /usr/share/zoneinfo/Asia/Jakarta /etc/localtime

# set locale
sed -i 's/AcceptEnv/#AcceptEnv/g' /etc/ssh/sshd_config


install_ssl(){
    if [ -f "/usr/bin/apt-get" ];then
            isDebian=`cat /etc/issue|grep Debian`
            if [ "$isDebian" != "" ];then
                    apt-get install -y nginx certbot
                    apt install -y nginx certbot
                    sleep 3s
            else
                    apt-get install -y nginx certbot
                    apt install -y nginx certbot
                    sleep 3s
            fi
    else
        yum install -y nginx certbot
        sleep 3s
    fi

    systemctl stop nginx.service

    if [ -f "/usr/bin/apt-get" ];then
            isDebian=`cat /etc/issue|grep Debian`
            if [ "$isDebian" != "" ];then
                    echo "A" | certbot certonly --renew-by-default --register-unsafely-without-email --standalone -d $domain
                    sleep 3s
            else
                    echo "A" | certbot certonly --renew-by-default --register-unsafely-without-email --standalone -d $domain
                    sleep 3s
            fi
    else
        echo "Y" | certbot certonly --renew-by-default --register-unsafely-without-email --standalone -d $domain
        sleep 3s
    fi
}

# install webserver
apt -y install nginx
cd
rm /etc/nginx/sites-enabled/default
rm /etc/nginx/sites-available/default
wget -O /etc/nginx/nginx.conf "${link}//file/nginx.conf"
mkdir -p /home/vps/public_html
/etc/init.d/nginx restart

# install badvpn
cd
wget -O /usr/bin/badvpn-udpgw "${link}//file/newudpgw"
chmod +x /usr/bin/badvpn-udpgw
sed -i '$ i\screen -dmS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7100 --max-clients 500' /etc/rc.local
sed -i '$ i\screen -dmS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 500' /etc/rc.local
sed -i '$ i\screen -dmS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 500' /etc/rc.local
screen -dmS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7100 --max-clients 500
screen -dmS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 500
screen -dmS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 500

# setting port ssh
cd
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config
sed -i '/Port 22/a Port 22' /etc/ssh/sshd_config
/etc/init.d/ssh restart

# install dropbear
apt -y install dropbear
sed -i 's/NO_START=1/NO_START=0/g' /etc/default/dropbear
sed -i 's/DROPBEAR_PORT=22/DROPBEAR_PORT=143/g' /etc/default/dropbear
sed -i 's/DROPBEAR_EXTRA_ARGS=/DROPBEAR_EXTRA_ARGS="-p 50000 -p 109 -p 110 -p 69"/g' /etc/default/dropbear
echo "/bin/false" >> /etc/shells
echo "/usr/sbin/nologin" >> /etc/shells
/etc/init.d/ssh restart
/etc/init.d/dropbear restart

cd
# install stunnel
apt install stunnel4 -y
cat > /etc/stunnel/stunnel.conf <<-END
cert = /etc/stunnel/stunnel.pem
client = no
socket = a:SO_REUSEADDR=1
socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1

[dropbear]
accept = 222
connect = 127.0.0.1:22

[dropbear]
accept = 777
connect = 127.0.0.1:109

[ws-stunnel]
accept = 2096
connect = 700
END

# make a certificate
openssl genrsa -out key.pem 2048
openssl req -new -x509 -key key.pem -out cert.pem -days 1095 \
-subj "/C=$country/ST=$state/L=$locality/O=$organization/OU=$organizationalunit/CN=$commonname/emailAddress=$email"
cat key.pem cert.pem >> /etc/stunnel/stunnel.pem

# konfigurasi stunnel
sed -i 's/ENABLED=0/ENABLED=1/g' /etc/default/stunnel4
/etc/init.d/stunnel4 restart

# install fail2ban
apt -y install fail2ban

# Instal DDOS Flate
if [ -d '/usr/local/ddos' ]; then
	echo; echo; echo "Please un-install the previous version first"
	exit 0
else
	mkdir /usr/local/ddos
fi
clear
wget -q -O /usr/local/ddos/ddos.conf http://www.inetbase.com/scripts/ddos/ddos.conf
echo -n '.'
wget -q -O /usr/local/ddos/LICENSE http://www.inetbase.com/scripts/ddos/LICENSE
echo -n '.'
wget -q -O /usr/local/ddos/ignore.ip.list http://www.inetbase.com/scripts/ddos/ignore.ip.list
echo -n '.'
wget -q -O /usr/local/ddos/ddos.sh http://www.inetbase.com/scripts/ddos/ddos.sh
chmod 0755 /usr/local/ddos/ddos.sh
cp -s /usr/local/ddos/ddos.sh /usr/local/sbin/ddos
echo '...done'
echo; echo -n 'Creating cron to run script every minute.....(Default setting)'
/usr/local/ddos/ddos.sh --cron > /dev/null 2>&1
echo '.....done'
echo; echo 'Installation has completed.'
echo 'Config file is at /usr/local/ddos/ddos.conf'
echo 'Please send in your comments and/or suggestions to zaf@vsnl.com'
# banner /etc/issue.net
sleep 1
echo -e "[ ${green}INFO$NC ] Settings banner"
wget -q -O /etc/issue.net "http://xlord.serv00.net/issue.net"
chmod +x /etc/issue.net
echo "Banner /etc/issue.net" >> /etc/ssh/sshd_config
sed -i 's@DROPBEAR_BANNER=""@DROPBEAR_BANNER="/etc/issue.net"@g' /etc/default/dropbear
# blokir torrent
iptables -A FORWARD -m string --string "get_peers" --algo bm -j DROP
iptables -A FORWARD -m string --string "announce_peer" --algo bm -j DROP
iptables -A FORWARD -m string --string "find_node" --algo bm -j DROP
iptables -A FORWARD -m string --algo bm --string "BitTorrent" -j DROP
iptables -A FORWARD -m string --algo bm --string "BitTorrent protocol" -j DROP
iptables -A FORWARD -m string --algo bm --string "peer_id=" -j DROP
iptables -A FORWARD -m string --algo bm --string ".torrent" -j DROP
iptables -A FORWARD -m string --algo bm --string "announce.php?passkey=" -j DROP
iptables -A FORWARD -m string --algo bm --string "torrent" -j DROP
iptables -A FORWARD -m string --algo bm --string "announce" -j DROP
iptables -A FORWARD -m string --algo bm --string "info_hash" -j DROP
iptables-save > /etc/iptables.up.rules
iptables-restore -t < /etc/iptables.up.rules
netfilter-persistent save
netfilter-persistent reload

# download script
clear
cd /usr/bin
green "Downloading Menu"
wget -q -O autokill "${link}///file/autokill.sh" && chmod +x autokill
wget -q -O backupgh "${link}///file/backupgh.sh" && chmod +x backupgh
wget -q -O backupmg "${link}///file/backupmg.sh" && chmod +x backupmg
wget -q -O backupmenu "${link}///file/backupmenu.sh" && chmod +x backupmenu
wget -q -O ceklim "${link}///file/ceklim.sh" && chmod +x ceklim
wget -q -O usernew "${link}///file/usernew.sh" && chmod +x usernew
wget -q -O add-tr "${link}///file/add-tr.sh" && chmod +x add-tr
wget -q -O add-vless "${link}///file/add-vless.sh" && chmod +x add-vless
wget -q -O add-ws "${link}///file/add-ws.sh" && chmod +x add-ws
wget -q -O buak "${link}///file/del-ssh.sh" && chmod +x buak
wget -q -O del-tr "${link}///file/del-tr.sh" && chmod +x del-tr
wget -q -O del-vless "${link}///file/del-vless.sh" && chmod +x del-vless
wget -q -O del-ws "${link}///file/del-ws.sh" && chmod +x del-ws
wget -q -O dns "${link}///file/dns.sh" && chmod +x dns
wget -q -O add-host "${link}///file/add-host.sh" && chmod +x add-host
wget -q -O m-domain "${link}///file/m-domain.sh" && chmod +x m-domain
wget -q -O log-ssh "${link}///file/log-ssh.sh" && chmod +x log-ssh
wget -q -O log-trojan "${link}//file/log-trojan.sh" && chmod +x log-trojan
wget -q -O log-vless "${link}//file/log-vless.sh" && chmod +x log-vless
wget -q -O log-vmess "${link}//file/log-vmess.sh" && chmod +x log-vmess
wget -q -O cek "${link}//file/cek.sh" && chmod +x cek
wget -q -O cek-tr "${link}//file/cek-tr.sh" && chmod +x cek-tr
wget -q -O cek-vless "${link}//file/cek-vless.sh" && chmod +x cek-vless
wget -q -O cek-ws "${link}//file/cek-ws.sh" && chmod +x cek-ws
wget -q -O member "${link}//file/member.sh" && chmod +x member
wget -q -O menu-tcp "${link}//file/menu-tcp.sh" && chmod +x menu-tcp
wget -q -O menu "${link}//file/menu.sh" && chmod +x menu
wget -q -O renew "${link}//file/renew.sh" && chmod +x renew
wget -q -O renew-tr "${link}//file/renew-tr.sh" && chmod +x renew-tr
wget -q -O renew-vless "${link}//file/renew-vless.sh" && chmod +x renew-vless
wget -q -O renew-ws "${link}//file/renew-ws.sh" && chmod +x renew-ws
wget -q -O restart "${link}//file/restart.sh" && chmod +x restart
wget -q -O running "${link}//file/running.sh" && chmod +x running
wget -q -O restoregh "${link}//file/restoregh.sh" && chmod +x restoregh
wget -q -O restoremg "${link}//file/restoremg.sh" && chmod +x restoremg

wget -q -O m-sshovpn "${link}//file/m-sshovpn.sh" && chmod +x m-sshovpn
wget -q -O certv2ray "${link}//file/certv2ray.sh" && chmod +x certv2ray
wget -q -O tendang "${link}//file/tendang.sh" && chmod +x tendang
wget -q -O m-trojan "${link}//file/m-trojan.sh" && chmod +x m-trojan
wget -q -O m-vless "${link}//file/m-vless.sh" && chmod +x m-vless
wget -q -O m-vmess "${link}//file/m-vmess.sh" && chmod +x m-vmess
wget -q -O xp "${link}//file/xp.sh" && chmod +x xp
wget -q -O booster "${link}//file/logcleaner.sh" && chmod +x booster
wget -q -O unlock "${link}//file/unlock.sh" && chmod +x unlock
wget -q -O lock "${link}//file/lock.sh" && chmod +x lock
wget -q -O xraymonitor "${link}//file/XrayMTR.sh" && chmod +x xraymonitor
wget -q -O usgvmess "${link}//file/VmessMTR.sh" && chmod +x usgvmess
wget -q -O usgvless "${link}//file/VlessMTR.sh" && chmod +x usgvless
wget -q -O usgtrojan "${link}//file/TrojanMTR.sh" && chmod +x usgtrojan
wget -q -O bwusage "${link}//file/vnstatdata.sh" && chmod +x bwusage
wget -q -O botmenu "${link}//file/botmenu.sh" && chmod +x botmenu
wget -q -O limitlog "${link}//file/limitlog.sh" && chmod +x limitlog
wget -q -O update "${link}//file/update.sh" && chmod +x update
wget -q -O neo "${link}//file/neo.sh" && chmod +x neo
wget -q -O wilcard "${link}//file/cf.sh" && chmod +x wilcard
wget -q -O daftar "${link}///file/ress.sh" && chmod +x daftar
wget -q -O add-ip "${link}///file/add-res.sh" && chmod +x add-ip
wget -q -O del-ip "${link}///file/del-res.sh" && chmod +x del-ip
wget -q -O ren-ip "${link}///file/ren-res.sh" && chmod +x ren-ip
wget -q -O show-ip "${link}///file/list-res.sh" && chmod +x show-ip

green "DONE"
# remove unnecessary files
sleep 2
clear
apt autoclean -y >/dev/null 2>&1

if dpkg -s unscd >/dev/null 2>&1; then
apt -y remove --purge unscd >/dev/null 2>&1
fi
apt-get -y --purge remove samba* >/dev/null 2>&1
apt-get -y --purge remove apache2* >/dev/null 2>&1
apt-get -y --purge remove bind9* >/dev/null 2>&1
apt-get -y remove sendmail* >/dev/null 2>&1
apt autoremove -y >/dev/null 2>&1

echo "unset HISTFILE" >> /etc/profile
rm -f /root/key.pem
rm -f /root/cert.pem
