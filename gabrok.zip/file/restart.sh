#!/bin/bash
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
gb="\e[92;1m"
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
function line_atas(){
echo -e " ${CYAN}┌────────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└────────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
##
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
MYIP=$(wget -qO- ipinfo.io/ip);

echo "Checking VPS"
CEKEXPIRED () {
    today=$(date -d +1day +%Y-%m-%d)
    Exp1=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
    if [[ $today < $Exp1 ]]; then
    echo -e "\e[32mSTATUS SCRIPT AKTIF...\e[0m"
    else
    echo -e "\e[31mSCRIPT ANDA EXPIRED!\e[0m";
    exit 0
fi
}
IZIN=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | awk '{print $4}' | grep $MYIP)
if [ $MYIP = $IZIN ]; then
echo -e "\e[32mPermission Accepted...\e[0m"
CEKEXPIRED
else
echo -e "\e[31mPermission Denied!\e[0m";

exit 0
fi
clear
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
clear 
line_atas
purple "       •••• Restart Service Menu ••••            \E[0m"
line_bawah
line_atas
echo -e " ${CYAN}│  ${gb}[1]• ${b} Restart All Services"
echo -e " ${CYAN}│  ${gb}[2]• ${b} Restart OpenSSH"
echo -e " ${CYAN}│  ${gb}[3]• ${b} Restart Dropbear"
echo -e " ${CYAN}│  ${gb}[4]• ${b} Restart Stunnel"
echo -e " ${CYAN}│  ${gb}[5]• ${b} Restart Nginx"
echo -e " ${CYAN}│  ${gb}[6]• ${b} Restart Badvpn"
echo -e " ${CYAN}│  ${gb}[7]• ${b} Restart XRAY"
echo -e " ${CYAN}│  ${gb}[8]• ${b} Restart WEBSOCKET"
line_bawah
line_atas
echo -e " ${CYAN}│  ${gb}[0]• ${b} Go Back To Menu"
line_bawah
echo -e "" 
echo -e ""
read -p " Select menu : " Restart
echo -e ""
sleep 1
clear
case $Restart in
                1)
                clear
line_atas
purple "       •••• Restart All Servive ••••            \E[0m"
line_bawah
line_atas
                echo -e "[ \033[32mInfo\033[0m ] Restart Begin, Please Wait"
                echo ""
                sleep 1
                systemctl restart ssh
                echo -e "[ \033[32mInfo\033[0m ] Done ! SSH Restarted"
                sleep 1
                echo -e "[ \033[36mInfo\033[0m ] Restarting Cron"
                systemctl restart cron
                sleep 2
                echo -e "[ \033[36mInfo\033[0m ] Restart Begin"
                echo ""
                systemctl restart net0
                sleep 2
                systemctl restart dropbear
                echo -e "[ \033[32mInfo\033[0m ] Done ! Dropbear Restarted"
                sleep 1
                systemctl restart stunnel4
                echo -e "[ \033[32mInfo\033[0m ] Done ! Stunnel Restarted"
                sleep 1
                systemctl restart nginx
                echo -e "[ \033[32mInfo\033[0m ] Done ! Nginx Restarted"
                sleep 1
                systemctl restart xray
                systemctl restart xray.service
                echo -e "[ \033[32mInfo\033[0m ] Done ! Xray Restarted"
                sleep 1
                screen -dmS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 500
                echo -e "[ \033[32mInfo\033[0m ] Done ! BadVPN Restarted"
                sleep 1
                systemctl restart ws-stunnel.service 
                systemctl restart ws-dropbear.service 
                echo -e "[ \033[32mInfo\033[0m ] Done ! Websocket Restarted"
                sleep 1
                echo ""
                echo -e "[ \033[32mInfo\033[0m ] Succesfully All Service Restarted"
                echo ""
line_tengah         
                echo ""
                read -n 1 -s -r -p "Press any key to back on system menu"
                restart
                ;;
                2)
                clear
line_atas
purple "       •••• Restart Ssh Service ••••            \E[0m"
line_bawah
line_atas
                echo -e "[ \033[32mInfo\033[0m ] Restart Begin"
                sleep 1
                systemctl restart ssh
                sleep 0.5
                echo -e "[ \033[32mInfo\033[0m ] SSH Service Restarted"
                echo ""
line_tengah
                echo ""
                read -n 1 -s -r -p "Press any key to back on system menu"
                restart
                ;;
                3)
                clear
line_atas
purple "       •••• Restart Dropbear Service ••••            \E[0m"
line_bawah
line_atas
                echo -e "[ \033[32mInfo\033[0m ] Restart Begin"
                sleep 1
                systemctl restart dropbear
                sleep 0.5
                echo -e "[ \033[32mInfo\033[0m ] Dropbear Service Restarted"
                echo ""
line_tengah
                echo ""
                read -n 1 -s -r -p "Press any key to back on system menu"
                restart
                ;;
                4)
                clear
line_atas
purple "       •••• Restart Stunnel Service ••••            \E[0m"
line_bawah
line_atas
                echo -e "[ \033[32mInfo\033[0m ] Restart Begin"
                sleep 1
                systemctl restart stunnel4
                sleep 0.5
                echo -e "[ \033[32mInfo\033[0m ] Stunnel Service Restarted"
                echo ""
line_tengah
                echo ""
                read -n 1 -s -r -p "Press any key to back on system menu"
                restart
                ;;
                5)
                clear
line_atas
purple "       •••• Restart Nginx Service ••••            \E[0m"
line_bawah
line_atas
                echo -e "[ \033[32mInfo\033[0m ] Restart Begin"
                sleep 1
                systemctl restart nginx
                sleep 0.5
                echo -e "[ \033[32mInfo\033[0m ] Nginx Service Restarted"
                echo ""
line_tengah
                echo ""
                read -n 1 -s -r -p "Press any key to back on system menu"
                restart
                ;;
                6)
                clear
line_atas
purple "       •••• Restart Badvpn Service ••••            \E[0m"
line_bawah
line_atas
                echo -e "[ \033[32mInfo\033[0m ] Restart Begin"
                sleep 1
                screen -dmS badvpn badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 500
                sleep 0.5
                echo -e "[ \033[32mInfo\033[0m ] Badvpn Service Restarted"
                echo ""
line_tengah
                echo ""
                read -n 1 -s -r -p "Press any key to back on system menu"
                restart
                ;;
                7)
                clear
line_atas
purple "       •••• Restart Xray Service ••••            \E[0m"
line_bawah
line_atas
                echo -e "[ \033[32mInfo\033[0m ] Restart Begin"
                sleep 1
                systemctl restart xray
                systemctl restart xray.service
                sleep 0.5
                echo -e "[ \033[32mInfo\033[0m ] XRAY Service Restarted"
                echo ""
line_tengah
                echo ""
                read -n 1 -s -r -p "Press any key to back on system menu"
                restart
                ;;
                8)
                clear
line_atas
purple "       •••• Restart Websocket Service ••••            \E[0m"
line_bawah
line_atas
                echo -e "[ \033[32mInfo\033[0m ] Restart Begin"
                sleep 1
                systemctl restart ws-stunnel.service 
                systemctl restart ws-dropbear.service
                sleep 0.5
                echo -e "[ \033[32mInfo\033[0m ] Websocket Service Restarted"
                echo ""
line_tengah
                echo ""
                read -n 1 -s -r -p "Press any key to back on system menu"
                restart
                ;;                                                                         
                0)
                menu
                exit
                ;;
                x)
                clear
                exit
                ;;
                *) echo -e "" ; echo "Tekan Yang Bener Dlogok" ; sleep 1 ; restart ;;               
        esac
