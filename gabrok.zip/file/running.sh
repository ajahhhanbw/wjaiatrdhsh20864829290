#!/bin/bash
# Provide by xlrd × dimz
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
g="\033[1;93m"
gb="\e[92;1m"
b="\033[0;36m"
p="\033[0m"
r="\033[0;31m"
y="\033[0;33"
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
clear
function line_atas(){
echo -e " ${cyan}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${cyan}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${cyan}────────────────────────────────────────${p}"
}

# GETTING OS INFORMATION
source /etc/os-release
Versi_OS=$VERSION
ver=$VERSION_ID
Tipe=$NAME
URL_SUPPORT=$HOME_URL
basedong=$ID

# CHEK STATUS 
tls_v2ray_status=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
nontls_v2ray_status=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
vless_tls_v2ray_status=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
vless_nontls_v2ray_status=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
shadowsocks=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
trojan_server=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
dropbear_status=$(/etc/init.d/dropbear status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
stunnel_service=$(/etc/init.d/stunnel4 status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
ssh_service=$(/etc/init.d/ssh status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
vnstat_service=$(/etc/init.d/vnstat status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
cron_service=$(/etc/init.d/cron status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
fail2ban_service=$(/etc/init.d/fail2ban status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
wstls=$(systemctl status ws-stunnel.service | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
wsdrop=$(systemctl status ws-dropbear.service | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
udpcustom=$(systemctl status udp-custom.service | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)



# COLOR VALIDATION
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
clear

# STATUS SERVICE OPENVPN
if [[ $udpcustom == "running" ]]; then
  status_udp=" ${b}[Online]${gb} ✓${p}"
else
  status_udp="${r}[Offline]${gb} x${p}"
fi

# STATUS SERVICE  SSH 
if [[ $ssh_service == "running" ]]; then 
   status_ssh=" ${b}[Online]${gb} ✓${p}"
else
   status_ssh="${r}[Offline]${gb} x${p}"
fi

# STATUS SERVICE  SQUID 
if [[ $squid_service == "running" ]]; then 
   status_squid=" ${b}[Online]${gb} ✓${p}"
else
   status_squid="${r}[Offline]${gb} x${p}"
fi

# STATUS SERVICE  VNSTAT 
if [[ $vnstat_service == "running" ]]; then 
   status_vnstat=" ${b}[Online]${gb} ✓${p}"
else
   status_vnstat="${r}[Offline]${gb} x${p}"
fi

# STATUS SERVICE  CRONS 
if [[ $cron_service == "running" ]]; then 
   status_cron=" ${b}[Online]${gb} ✓${p}"
else
   status_cron="${r}[Offline]${gb} x${p}"
fi

# STATUS SERVICE  FAIL2BAN 
if [[ $fail2ban_service == "running" ]]; then 
   status_fail2ban=" ${b}[Online]${gb} ✓${p}"
else
   status_fail2ban="${r}[Offline]${gb} x${p}"
fi

# STATUS SERVICE  TLS 
if [[ $tls_v2ray_status == "running" ]]; then 
   status_tls_v2ray=" ${b}[Online]${gb} ✓${p}"
else
   status_tls_v2ray="${r}[Offline]${gb} x${p}"
fi

# STATUS SERVICE NON TLS V2RAY
if [[ $nontls_v2ray_status == "running" ]]; then 
   status_nontls_v2ray=" ${b}[Online]${gb} ✓${p}"
else
   status_nontls_v2ray="${r}[Offline]${gb} x${p} "
fi

# STATUS SERVICE VLESS HTTPS
if [[ $vless_tls_v2ray_status == "running" ]]; then
  status_tls_vless=" ${b}[Online]${gb} ✓${p}"
else
  status_tls_vless="${r}[Offline]${gb} x${p} "
fi

# STATUS SERVICE VLESS HTTP
if [[ $vless_nontls_v2ray_status == "running" ]]; then
  status_nontls_vless=" ${b}[Online]${gb} ✓${p}"
else
  status_nontls_vless="${r}[Offline]${gb} x${p} "
fi
# STATUS SERVICE TROJAN
if [[ $trojan_server == "running" ]]; then 
   status_virus_trojan=" ${b}[Online]${gb} ✓${p}"
else
   status_virus_trojan="${r}[Offline]${gb} x${p} "
fi
# STATUS SERVICE DROPBEAR
if [[ $dropbear_status == "running" ]]; then 
   status_beruangjatuh=" ${b}[Online]${gb} ✓${p}"
else
   status_beruangjatuh="${r}[Offline]${gb} x${p} "
fi

# STATUS SERVICE STUNNEL
if [[ $stunnel_service == "running" ]]; then 
   status_stunnel=" ${b}[Online]${gb} ✓${p}"
else
   status_stunnel="${r}[Offline]${gb} x${p}"
fi
# STATUS SERVICE WEBSOCKET TLS
if [[ $wstls == "running" ]]; then 
   swstls=" ${b}[Online]${gb} ✓${p}"
else
   swstls="${r}[Offline]${gb} x${p} "
fi

# STATUS SERVICE WEBSOCKET DROPBEAR
if [[ $wsdrop == "Running" ]]; then 
   swsdrop=" ${b}[Online]${gb} ✓${p}"
else
   swsdrop="${r}[Offline]${gb} x${p} "
fi

# STATUS SHADOWSOCKS
if [[ $shadowsocks == "running" ]]; then 
   status_shadowsocks=" ${b}[Online]${gb} ✓${p}"
else
   status_shadowsocks="${r}[Offline]${gb} x${p} "
fi



# TOTAL RAM
total_ram=` grep "MemTotal: " /proc/meminfo | awk '{ print $2}'`
totalram=$(($total_ram/1024))

# KERNEL TERBARU
kernelku=$(uname -r)
#tipeos2=$(uname -m)
Name=$(cat /etc/securedata/name)
MYIP=$(cat /etc/securedata/ip1)
# GETTING DOMAIN NAME
Domen="$(cat /etc/xray/domain)"
ISP=$(cat /usr/local/etc/xray/org)
CITY=$(cat /usr/local/etc/xray/city)
echo -e ""
line_atas
purple "       •••• Service Status ••••            \E[0m"
line_bawah
line_atas
echo -e " ${cyan}│💥 SSH / TUN               :$status_ssh"
echo -e " ${cyan}│💥 UDP Service             :$status_udp"
echo -e " ${cyan}│💥 Dropbear                :$status_beruangjatuh"
echo -e " ${cyan}│💥 Stunnel4                :$status_stunnel"
echo -e " ${cyan}│💥 Fail2Ban                :$status_fail2ban"
echo -e " ${cyan}│💥 Crons                   :$status_cron"
echo -e " ${cyan}│💥 Vnstat                  :$status_vnstat"
echo -e " ${cyan}│💥 XRAY Vmess              :$status_tls_v2ray"
echo -e " ${cyan}│💥 XRAY Vless              :$status_tls_vless"
echo -e " ${cyan}│💥 XRAY Trojan             :$status_virus_trojan"
echo -e " ${cyan}│💥 Websocket Services      :$swstls"
line_bawah
echo ""
read -n 1 -s -r -p "Press any key to back"
menu
