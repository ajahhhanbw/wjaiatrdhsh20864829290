#!/bin/bash
# Provide by xlrd × dimz
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
g="\033[1;93m"
gb="\e[92;1m"
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
# XLORD GANTENG 
TOKEN="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"
clear
EMAILGIT="salamsatuuuu@gmail.com"
USERGIT="salamsatuu"
rm -rf /root/psby
git config --global user.email "${EMAILGIT}"
git config --global user.name "${USERGIT}"
git clone https://github.com/${USERGIT}/psby.git
cd /root/psby/
rm -rf .git
git init
touch ip
clear
line_atas
echo -e " ${CYAN}│${NC}${g}    .::.${NC}    LIST MEMBER     ${NC}${g}.::. $NC"
line_bawah
echo -e "${CYAN} NAMA <<--->> EXPIRED <<--->> IP VPS ${NC}"
grep -E "^###" "/root/psby/daftar" | cut -d ' ' -f 2-6 | column -t | sort | uniq
grep -E "^#&"  "/root/psby/daftar" | cut -d ' ' -f 2-6 | column -t | sort | uniq
line_bawah
read -p "Input IP Address To Delete : " ipdel
name=$(cat /root/psby/daftar | grep $ipdel | awk '{print $2}')
exp=$(cat /root/psby/daftar | grep $ipdel | awk '{print $3}')
if [[ ${exp} == 'Lifetime' ]]; then
sed -i "/^#&   $name   $exp $ipdel/,/^},{/d" /root/psby/daftar
else
sed -i "/^### $name $exp $ipdel/,/^},{/d" /root/psby/daftar
fi
cd /root/psby
git config --global user.email "${EMAIL}" &> /dev/null
git config --global user.name "${USER}" &> /dev/null
rm -rf .git &> /dev/null
git init &> /dev/null
git add . &> /dev/null
git commit -m m &> /dev/null
git branch -M main &> /dev/null
git remote add origin https://github.com/salamsatuu/psby
git push -f https://${TOKEN}@github.com/salamsatuu/psby.git &> /dev/null
rm -rf /root/backend
clear
sleep 1
echo "  Delete IP Address..."
sleep 1
echo "  Processing..."
sleep 1
echo "  Done!"
sleep 1
clear
echo -e "${CYAN}┌───────────────────────────────┐$NC"
echo -e "${CYAN}│${NC}${g} .::.${NC} DONE DELETE IP VPS ${NC}${g}.::. $NC"
echo -e "${CYAN}└───────────────────────────────┘$NC"
echo -e "${GREEN}> USERNAME   :${NC}${yell} $name"
echo -e "${GREEN}> IP ADDRESS :${NC}${yell} $ipdel"
echo -e "${GREEN}> EXPIRED ON :${NC}${yell} $exp"
echo -e " ${CYAN}────────────────────────────────$NC"
echo -e ""
read -n 1 -s -r -p "Press any key to back"
daftar