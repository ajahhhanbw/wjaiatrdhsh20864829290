#!/bin/bash
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
#---------------
clear

NUMBER_OF_CLIENTS=$(grep -c -E "#&" "/etc/client/vls.txt")
	if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
		clear
           echo ""
    echo -e "${BLUE}┌━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┐\033[0m"
    echo -e "  ${BG_RED}           GAGAL MEMPERPANJANG             \E[0m"
    echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"
		echo ""
		echo " There are no members"
		echo ""
		echo -e " ${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
        echo ""
        read -n 1 -s -r -p "Press any key to back"
        m-vless
	fi

	clear
	  echo ""
    echo -e "${BLUE}┌━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┐\033[0m"
    echo -e "  ${BG_RED}           LIST MEMBER VLESS               \E[0m"
    echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"
    echo ""
  	grep -E "#&" "/etc/client/vls.txt" | cut -d ' ' -f 2-3 | column -t | sort | uniq
    echo ""
    echo -e " ${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
	read -rp " Input the Username : " user
   CLIENT_EXISTS=$(grep -w "#& $user" "/etc/client/vls.txt" | wc -l)
  if [[ ${CLIENT_EXISTS} == '0' ]]; then              
   clear
    echo "Failure User Not Found"
    sleep 2
    menu
    else
    clear                                                                        
    if [ -z $user ]; then
    echo "No input"
    menu
    else
    read -p "Quota : " Quota
    read -p "Expired (days): " masaaktif
     if [ -z ${Quota} ]; then
      Quota="0.1"
     fi
   c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
   d=$((${c} * 1024 * 1024 * 1024))
      if [[ ${c} != "0" ]]; then
       echo "${d}" >/etc/lmt/${user}
      fi
      usg="1024"
      echo "$usg" >/etc/usg/${user}
    exp=$(grep -wE "#& $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
    now=$(date +%Y-%m-%d)
    d1=$(date -d "$exp" +%s)
    d2=$(date -d "$now" +%s)
    exp2=$(( (d1 - d2) / 86400 ))
    exp3=$(($exp2 + $masaaktif))
    exp4=`date -d "$exp3 days" +"%Y-%m-%d"`
    sed -i "/#& $user/c\#& $user $exp4" /etc/xray/config.json
    sed -i "/#& $user/c\#& $user $exp4" /etc/client/vls.txt
    systemctl restart xray > /dev/null 2>&1
    clear
echo ""
    echo -e "${BLUE}┌━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┐\033[0m"
    echo -e "  ${BG_RED}           PERPANJANG VLESS SUCCESSFUL             \E[0m"
    echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"
    echo ""
    echo " Client Name : $user"
    echo " Expired On  : $exp4"
    echo ""
    echo -e " ${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    echo ""
    read -n 1 -s -r -p "Press any key to back"
    m-vless
    fi
  fi