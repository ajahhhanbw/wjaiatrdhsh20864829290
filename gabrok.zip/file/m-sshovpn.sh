#!/bin/bash
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
g="\e[36m"
gb="\e[92;1m"
PURPLE='\e[35m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
function line_atas(){
echo -e " ${g}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${g}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${g}────────────────────────────────────────${p}"
}
#---------------
BURIQ () {
    curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar > /root/tmp
    data=( `cat /root/tmp | grep -E "^### " | awk '{print $2}'` )
    for user in "${data[@]}"
    do
    exp=( `grep -E "^### $user" "/root/tmp" | awk '{print $3}'` )
    d1=(`date -d "$exp" +%s`)
    d2=(`date -d "$biji" +%s`)
    exp2=$(( (d1 - d2) / 86400 ))
    if [[ "$exp2" -le "0" ]]; then
    echo $user > /etc/.$user.ini
    else
    rm -f /etc/.$user.ini > /dev/null 2>&1
    fi
    done
    rm -f /root/tmp
}

MYIP=$(curl -sS ipv4.icanhazip.com)
Name=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $2}')
echo $Name > /usr/local/etc/.$Name.ini
CekOne=$(cat /usr/local/etc/.$Name.ini)

Bloman () {
if [ -f "/etc/.$Name.ini" ]; then
CekTwo=$(cat /etc/.$Name.ini)
    if [ "$CekOne" = "$CekTwo" ]; then
        res="Expired"
    fi
else
res="Permission Accepted..."
fi
}

PERMISSION () {
    MYIP=$(curl -sS ipv4.icanhazip.com)
    IZIN=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | awk '{print $4}' | grep $MYIP)
    if [ "$MYIP" = "$IZIN" ]; then
    Bloman
    else
    res="Permission Denied!"
    fi
    BURIQ
}

red='\e[1;31m'
green='\e[0;32m'
NC='\e[0m'
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
PERMISSION
if [ -f /home/needupdate ]; then
red "Your script need to update first !"
exit 0
elif [ "$res" = "Permission Accepted..." ]; then
echo -ne
else
red "Permission Denied!"
exit 0
fi
ssh1="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
let trb=$trx/2
clear
echo""
line_atas
purple "       •••• Shh Websocket Menu •••• "
line_bawah
line_atas
echo -e " ${g}│  ${gb}[1]• ${b} Create Akun Ssh "
echo -e " ${g}│  ${gb}[2]• ${b} Unlock user Ssh "
echo -e " ${g}│  ${gb}[3]• ${b} Renewal Ssh Akun "
echo -e " ${g}│  ${gb}[4]• ${b} Delete User Ssh "
echo -e " ${g}│  ${gb}[5]• ${b} Check User Login Ssh "
echo -e " ${g}│  ${gb}[6]• ${b} Daftar Member Ssh "
echo -e " ${g}│  ${gb}[7]• ${b} Set limit Ip User Ssh "
echo -e " ${g}│  ${gb}[8]• ${b} Check User Yang Melanggar "
echo -e " ${g}│  ${gb}[9]• ${b} History User Ssh"
line_bawah
line_atas
echo -e " ${g}│  ${gb}[0]• ${b} Go Back To Menu"
line_bawah
echo -e ""
line_atas
red "    Ssh Websocket Accounts : ${blue}$ssh1 USER \e[0m"
line_bawah
echo -e ""
read -p " Select menu :  "  opt
echo -e ""
case $opt in
1) clear ; usernew ; exit ;;
2) clear ; unlock ; exit ;;
3) clear ; renew ; exit ;;
4) clear ; buak ; exit ;;
5) clear ; cek ; exit ;;
6) clear ; member ; exit ;;
7) clear ; autokill ; exit ;;
8) clear ; ceklim ; exit ;;
9) clear ; log-ssh ; exit ;;
0) clear ; menu ; exit ;;
x) exit ;;
*) echo "Anda salah tekan " ; sleep 1 ; m-sshovpn ;;
esac
