#!/bin/bash
MYIP=$(wget -qO- ipinfo.io/ip);
echo "Mengecek Vps Anda..."
sleep 0.5
CEKEXPIRED () {
        today=$(date -d +1day +%Y -%m -%d)
        Exp1=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
        if [[ $today < $Exp1 ]]; then
        echo "status script aktif.."
        else
        echo "SCRIPT ANDA EXPIRED";
        exit 0
fi
}
IZIN=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | awk '{print $4}' | grep $MYIP)
if [ $MYIP = $IZIN ]; then
echo "Welcome To Sc Premium.."
sleep 1
else
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          404 NOT FOUND AUTOSCRIPT          \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}PERMISSION DENIED !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $MYIP \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      \033[0;36mTelegram${NC} t.me/xlordeuyy"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/62881036683241"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
exit 0
fi
clear
#EXPIRED
expired=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
echo $expired > /root/expired.txt
today=$(date -d +1day +%Y-%m-%d)
while read expired
do
        exp=$(echo $expired | curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
        if [[ $exp < $today ]]; then
                Exp2="\033[1;31mExpired\033[0m"
        else
        Exp2=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
        fi
done < /root/expired.txt
rm /root/expired.txt
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
b='\e[34m'
PURPLE='\e[35m'
gb='\033[0;37m'
cyan='\e[36m'
g='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
######################################

# // ───>>> BACKGROUND

function line_atas(){
echo -e "  ${g}┌─────────────────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e "  ${g}└─────────────────────────────────────────────────┘${p}"
}
function line_p(){
echo -e "  ${g}┌─────────────────────────────────────────────────•${p}"
}
function line_l() {
echo -e "  ${g}└─────────────────────────────────────────────────•${p}"
}
function line_ip() {
echo -e "  ${g}•─────────────────────────────────────────────────•${p}"
}
function line_pp() {
echo -e "  ${g}┌─────────────────────────────────•${p}"
}
function line_oo() {
echo -e "  ${g}└─────────────────────────────────•${p}"
}
function line_ae(){
echo -e "  ${g}•─────────────────────────────────────────────────┐${p}"
}
function line_ai() {
echo -e "  ${g}•─────────────────────────────────────────────────┘${p}"
}
# VPS Information
#Domain
domain=$(cat /etc/xray/domain)
#Status certificate
modifyTime=$(stat $HOME/.acme.sh/${domain}_ecc/${domain}.key | sed -n '7,6p' | awk '{print $2" "$3" "$4" "$5}')
modifyTime1=$(date +%s -d "${modifyTime}")
currentTime=$(date +%s)
cpu_usage1="$(ps aux | awk 'BEGIN {sum=0} {sum+=$3}; END {print sum}')"
cpu_usage="$((${cpu_usage1/\.*} / ${coREDiilik:-1}))"
cpu_usage+=" %"
stampDiff=$(expr ${currentTime} - ${modifyTime1})
days=$(expr ${stampDiff} / 86400)
MODEL=$(cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/"//g' | sed 's/PRETTY_NAME//g')
remainingDays=$(expr 90 - ${days})
tlsStatus=${remainingDays}
if [[ ${remainingDays} -le 0 ]]; then
        tlsStatus="expired"
fi
DATE=$(date +'%Y-%m-%d')
datediff() {
    d1=$(date -d "$1" +%s)
    d2=$(date -d "$2" +%s)
    echo -e "$COLOR1 $NC Expiry In   : $(( (d1 - d2) / 86400 )) Days"
}
mai="datediff "$Exp" "$DATE""

today=`date -d "0 days" +"%Y-%m-%d"`

# CERTIFICATE STATUS
Name=$(curl https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $2}')
d1=$(date -d "$exp" +%s)
d2=$(date -d "$today" +%s)
certificate=$(( (d1 - d2) / 86400 ))
# OS Uptime
uptime="$(uptime -p | cut -d " " -f 2-10)"
# Getting CPU Information
cpu_usage1="$(ps aux | awk 'BEGIN {sum=0} {sum+=$3}; END {print sum}')"
cpu_usage="$((${cpu_usage1/\.*} / ${corediilik:-1}))"
cpu_usage+=" %"
ISP=$(cat /usr/local/etc/xray/org)
WKT=$(cat /usr/local/etc/xray/timezone)
DAY=$(date +%A)
DATE=$(date +%m/%d/%Y)
DATE2=$(date -R | cut -d " " -f -5)
IPVPS=$(curl -s ipinfo.io/ip )
cname=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
cores=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
freq=$( awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo )
tram=$( free -m | awk 'NR==2 {print $2}' )
uram=$( free -m | awk 'NR==2 {print $3}' )
fram=$( free -m | awk 'NR==2 {print $4}' )
Dev="𝙓𝙡𝙤𝙧𝙙𝘿𝙞𝙢𝙯𝙓𝘿"
DATEVPS=$(date +'%d/%m/%Y')
TIMEZONE=$(printf '%(%H:%M:%S)T')
SERONLINE=$(uptime -p | cut -d " " -f 2-10000)
ssh1="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
vlx=$(grep -c -E "^#&" "/etc/xray/config.json")
let vla=$vlx/2
vmc=$(grep -c -E "^### " "/etc/xray/config.json")
let vma=$vmc/2
trx=$(grep -c -E "^#!" "/etc/xray/config.json")
let trb=$trx/2
clear
line_atas
echo -e " ${CYAN} │ ${gb}${BG_CYN}               ∆  XLORD × DIMZ  ∆              ${NC} ${CYAN}│$NC"
line_bawah
line_atas
echo -e " ${CYAN} │$NC $gb ISP ${gb}              : ${gb}$ISP${NC}"
echo -e " ${CYAN} │$NC $gb System Os ${gb}        : ${gb}$MODEL${NC}"
echo -e " ${CYAN} │$NC $gb IP VPS ${gb}           : ${gb}$IPVPS${NC}"
echo -e " ${CYAN} │$NC $gb UPTIME ${gb}           : $gb$uptime"
echo -e " ${CYAN} │$NC $gb DOMAIN ${gb}           : $gb$domain"
echo -e " ${CYAN} │$NC $gb RAM USAGE ${gb}        : $gb$uram MB | $gb$tram MB"
echo -e " ${CYAN} │$NC $gb CPU USAGE ${gb}        : $gb$cpu_usage"
line_bawah
echo -e " ${g}  ┌───────────────────────────────────────────┐${p}"
echo -e " ${g}          ${gb}• SSH         ${p}: ${g}${ssh1}$(printf '%*s' $((4 - ${#sshh})) '') ${gb}{Account}"
echo -e " ${g}          ${gb}• VMESS       ${p}: ${g}${vma}$(printf '%*s' $((4 - ${#vm})) '') ${gb}{Account}"
echo -e " ${g}          ${gb}• VLESS       ${p}: ${g}${vla}$(printf '%*s' $((4 - ${#vl})) '') ${gb}{Account}"
echo -e " ${g}          ${gb}• TROJAN      ${p}: ${g}${trb}$(printf '%*s' $((4 - ${#tr})) '') ${gb}{Account}"
echo -e " ${g}  └───────────────────────────────────────────┘${p}"
echo -e " ${g}┌───────────────────────────────────────────────┐${p}"
echo -e " ${g}│ │ ${gb}• Developer     ${p}: ${red}$Dev${p}"
echo -e " ${g}│ │ ${gb}• Client Name   ${p}: ${gb}$Name${p}"
echo -e " ${g}│ │ ${gb}• Exp Script    ${p}: ${b}$certificate Days${p}"
echo -e " ${g}└───────────────────────────────────────────────┘${p}"
echo -e " ${yell}          To Access ${cyan}Use ${yell}☞ menu ${cyan} Command ${p}"
echo ""
exit
