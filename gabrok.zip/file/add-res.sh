#!/bin/bash
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
g="\033[0;35m"
gb="\e[92;1m"
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
AS='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
####
function line_atas(){
echo -e "${CYAN}┌───────────────────────────────┐${p}"
}
function line_bawah() {
echo -e "${CYAN}└───────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "${CYAN}────────────────────────────────────────${p}"
}
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear

TOKEN="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"
today=`date -d "0 days" +"%Y-%m-%d"`
git clone https://github.com/salamsatuu/psby.git /root/psby/ &> /dev/null

line_atas
echo -e "${CYAN}│${NC}${g}    .::.${NC}${p} ADD IP VPS ${NC}${g}.::.       ${CYAN}│$NC"
line_bawah
read -p "Input IP Address : " ip
CLIENT_EXISTS=$(grep -w $ip /root/psby/daftar | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
echo "IP Already Exist !"
exit 0
fi
x="ok"

satu="ON"
dua="OFF"
while true $x != "ok"
do
line_atas
echo -e "${CYAN}│${NC}${g}   .::.${NC}${p} TYPE PENGGUNA ${NC}${g}.::.     ${CYAN}│$NC"
line_bawah
echo -e "$blue${NC}  ${LIGHT}[01]${blue} • ADMIN   ${LIGHT}[02]${blue} • CLIENT "
echo -e "$blue${NC}"
read -p "Type user: " list
echo ""
case "$list" in 
   1) isadmin="$satu";break;;
   2) isadmin="$dua";break;;
esac
done
clear
line_atas
echo -e "${CYAN}│${NC}${g} .::.${NC}${p} ADD USER PENGGUNA ${NC}${g}.::.   ${CYAN}│$NC"
line_bawah
read -rp "Name User: " -e user
name=$user`</dev/urandom tr -dc A-Z0-9 | head -c4`
clear
line_atas
echo -e "${CYAN}│${NC}${g} .::.${NC}${p} ADD DURASI PENGGUNA ${NC}${g}.::. ${CYAN}│$NC"
line_bawah
line_atas
echo -e "  ${GREEN} 1.${NC}${CYAN}30 Days${NC}"
echo -e "  ${GREEN} 2.${NC}${CYAN}60 Days${NC}"
echo -e "  ${GREEN} 3.${NC}${CYAN}90 Days${NC}"
echo -e "  ${GREEN} 4.${NC}${CYAN}Lifetime${NC}"
echo -e "  ${GREEN} 5.${NC}${CYAN}Custom Expiration Date${NC}"
line_bawah
echo""
read -p "Select Number 1 - 5 : " exp
if [[ ${exp} == '1' ]]; then
exp2=`date -d "30 days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip} $isadmin" >> /root/psby/daftar
elif [[ ${exp} == '2' ]]; then
exp2=`date -d "60 days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip} $isadmin" >> /root/psby/daftar
elif [[ ${exp} == '3' ]]; then
exp2=`date -d "90 days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip} $isadmin" >> /root/psby/daftar
elif [[ ${exp} == '4' ]]; then
exp2=`date -d "12000 days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip} $isadmin" >> /root/psby/daftar
elif [[ ${exp} == '5' ]]; then
read -p "Input Expired Days : " exp11
exp2=`date -d "$exp11 days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip} $isadmin" >> /root/psby/daftar
fi
cd /root/psby
git config --global user.email "${EMAIL}" &> /dev/null
git config --global user.name "${USER}" &> /dev/null
rm -rf .git &> /dev/null
git init &> /dev/null
git add . &> /dev/null
git commit -m m &> /dev/null
git branch -M main &> /dev/null
git remote add origin https://github.com/salamsatuu/psby
git push -f https://${TOKEN}@github.com/salamsatuu/psby.git &> /dev/null
rm -rf /root/psby
clear
sleep 1
echo "  Registering IP Address..."
sleep 1
echo "  Processing..."
sleep 1
echo "  Done!"
sleep 1
TIMES="10"
CHATID="-1002100547917"
KEY="6762647011:AAHJRQ-75tfGsnhq-bjfWz1kFUkMCyqIAXQ"
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT="
<code>───────────────────────</code>
<b> ⚡ SUKSES ADD NEW IP ⚡</b>
<code>───────────────────────</code>
<code>User    : </code><code>$name</code>
<code>Ip Vps  : </code><code>$ip</code>
<code>Admin   : </code><code>$isadmin</code>
<code>Registered On    : </code><code>$today</code>
<code>Expired On    : </code><code>$exp2</code>
<code>───────────────────────</code>
<i>Automatic Notification from</i>
<i>𝙓𝙡𝙤𝙧𝙙𝘿𝙞𝙢𝙯『✘𝕯』</i>
<code>───────────────────────</code>
"'&reply_markup={"inline_keyboard":[[{"text":"⚡ XLORD ⚡","url":"https://t.me/xlordeuyy"},{"text":"⚡ DIMZ ⚡","url":"https://wa.me/6285142317870"}]]}'
curl -s --max-time $TIMES -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
clear
echo -e "${CYAN}┌───────────────────────────────┐$NC"
echo -e "${CYAN}│${NC}${g}  .::.${NC}${p} SUCCES ADD IP VPS ${NC}${g}.::.  ${CYAN}│$NC"
echo -e "${CYAN}└───────────────────────────────┘$NC"
echo -e "${GREEN}> USERNAME   :${NC}${yell} $name"
echo -e "${GREEN}> IP ADDRESS :${NC}${yell} $ip"
echo -e "${GREEN}> REGISTERED :${NC}${yell} $today"
echo -e "${GREEN}> EXPIRED ON :${NC}${yell} $exp2"
echo -e " ${CYAN}────────────────────────────────$NC"
line_atas
echo -e "${p}  Terimakasih Telah Menggunakan $NC"
echo -e "${p}        Script Credit By $NC"
echo -e "${p}          Xlord × Dimz $NC"
line_bawah
echo -e ""
read -n 1 -s -r -p "Press any key to back"
daftar