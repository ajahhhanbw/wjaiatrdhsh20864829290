#!/bin/bash
# Provide by xlrd × dimz
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
g="\033[1;93m"
gb="\e[92;1m"
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
# Location Chat ID 
bwbot="/etc/securedata/chatidbw"
bakbot="/etc/securedata/chatidbak"
# Detail Chat ID
checkbwbot=$(cat /etc/securedata/chatidbw)
checkbakbot=$(cat /etc/securedata/chatidbak)
line_atas
purple "     •••• Manage Notify BOT •••• "
line_bawah
echo ""
echo "Note :"
echo -e "${ORANGE}To access Notify Bot you must search the Bot first,
the Bot name is${NC} ${BLUE}@xlordofc2_BOT${NC} ${ORANGE}and${NC} ${BLUE}@xlordofc3_BOT${NC} ${ORANGE}then
you can start the Bot and change the default Chat ID with your
own Telegram ChatID, the Bot will send backup data every
00.00 and bandwidth information every hours to you${NC}"
echo ""
echo -e "${RED}Current ChatID Bandwidth Bot${NC} : ${CYAN}$checkbwbot${NC}"
echo -e "${RED}Current ChatID Backup Bot${NC}    : ${CYAN}$checkbakbot${NC}"
echo ""
line_atas
echo -e " ${CYAN}│  ${gb}[1]• ${b}Change ChatID for Bandwidth Bot Only"
echo -e " ${CYAN}│  ${gb}[2]• ${b}Change ChatID for Backup Bot Only"
echo -e " ${CYAN}│  ${gb}[3]• ${b}Change All of ChatID"
line_bawah
line_atas
echo -e " ${CYAN}│  ${gb}[0]• ${b} Go Back To Menu"
line_bawah
echo -e ""
read -p "Select => " option
if [ -z $option ]; then
menu
fi
echo -e ""
case $option in
    1)
    clear
    echo -e ""
    read -p "Your ChatID => " bwchatid
    if [ -z $bwchatid ]; then
    botmenu
    else
    echo "$bwchatid" > $bwbot
    green "ChatID Added"
    sleep 2
    botmenu
    fi
    ;;
    
    2)
    clear
    echo -e ""
    read -p "Your ChatID => " bakchatid
    if [ -z $bakchatid ]; then
    botmenu
    else
    echo "$bakchatid" > $bakbot
    green "ChatID Added"
    sleep 2
    botmenu
    fi
    ;;
    
    3)
    clear
    echo -e ""
    read -p "Your ChatID => " allchatid
    if [ -z $allchatid ]; then
    botmenu
    else
    echo "$allchatid" > $bwbot
    echo "$allchatid" > $bakbot
    green "ChatID Added"
    sleep 2    
    botmenu
    fi
    ;;
    
    *)
    clear
    menu
    ;;
 esac
option
