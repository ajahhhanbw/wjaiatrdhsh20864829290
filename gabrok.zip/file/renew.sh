#!/bin/bash
# Provide by xlrd × dimz
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
echo ""
    echo -e "${BLUE}┌━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┐\033[0m"
    echo -e "  ${BG_RED}        •••• PERPANJANG AKUN SSH ••••              \E[0m"
    echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"

echo -e "${BLUE}┌━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┐\033[0m"
echo " USERNAME          EXP DATE          STATUS"
echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"
while read expired
do
AKUN="$(echo $expired | cut -d: -f1)"
ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
status="$(passwd -S $AKUN | awk '{print $2}' )"
if [[ $ID -ge 1000 ]]; then
if [[ "$status" = "L" ]]; then
printf "%-17s %2s %-17s %2s \n"   "$AKUN" "$exp     " "LOCKED"
else
printf "%-17s %2s %-17s %2s \n"   "$AKUN" "$exp     " "UNLOCKED"
fi
fi
done < /etc/passwd
echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"
echo ""
echo "Please input the Username"
echo ""
read -p "Username => " User
if [ -z $User ]; then
clear
m-sshovpn
fi
egrep "^$User" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
read -p "Day Extend : " Days
Today=`date +%s`
Days_Detailed=$(( $Days * 86400 ))
Expire_On=$(($Today + $Days_Detailed))
Expiration=$(date -u --date="1970-01-01 $Expire_On sec GMT" +%Y/%m/%d)
Expiration_Display=$(date -u --date="1970-01-01 $Expire_On sec GMT" '+%d %b %Y')
passwd -u $User
usermod -e  $Expiration $User
egrep "^$User" /etc/passwd >/dev/null
echo -e "$Pass\n$Pass\n"|passwd $User &> /dev/null
clear
    echo -e "${BLUE}┌━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┐\033[0m"
    echo -e "  ${BG_RED} AKUN BERHASIL DIPERPANJANG      \E[0m"
    echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"
    echo -e " Username   : $User"
    echo -e " Days Added : $Days Days"
    echo -e " Expires on : $Expiration_Display"
    echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"
echo ""
read -n 1 -s -r -p "Press any key to back"
clear
m-sshovpn
else
red " User not found "
sleep 2
clear
renew
fi
