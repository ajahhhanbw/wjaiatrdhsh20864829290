#!/bin/bash
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
g="\e[36m"
gb="\e[92;1m"
PURPLE='\e[35m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
function line_atas(){
echo -e " ${g}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${g}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${g}────────────────────────────────────────${p}"
}
#---------------
BURIQ () {
    curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar > /root/tmp
    data=( `cat /root/tmp | grep -E "^### " | awk '{print $2}'` )
    for user in "${data[@]}"
    do
    exp=( `grep -E "^### $user" "/root/tmp" | awk '{print $3}'` )
    d1=(`date -d "$exp" +%s`)
    d2=(`date -d "$biji" +%s`)
    exp2=$(( (d1 - d2) / 86400 ))
    if [[ "$exp2" -le "0" ]]; then
    echo $user > /etc/.$user.ini
    else
    rm -f /etc/.$user.ini > /dev/null 2>&1
    fi
    done
    rm -f /root/tmp
}

MYIP=$(curl -sS ipv4.icanhazip.com)
Name=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $2}')
echo $Name > /usr/local/etc/.$Name.ini
CekOne=$(cat /usr/local/etc/.$Name.ini)

Bloman () {
if [ -f "/etc/.$Name.ini" ]; then
CekTwo=$(cat /etc/.$Name.ini)
    if [ "$CekOne" = "$CekTwo" ]; then
        res="Expired"
    fi
else
res="Permission Accepted..."
fi
}

PERMISSION () {
    MYIP=$(curl -sS ipv4.icanhazip.com)
    IZIN=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | awk '{print $4}' | grep $MYIP)
    if [ "$MYIP" = "$IZIN" ]; then
    Bloman
    else
    res="Permission Denied!"
    fi
    BURIQ
}

red='\e[1;31m'
green='\e[0;32m'
NC='\e[0m'
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
PERMISSION
if [ -f /home/needupdate ]; then
red "Your script need to update first !"
exit 0
elif [ "$res" = "Permission Accepted..." ]; then
echo -ne
else
red "Permission Denied!"
exit 0
fi
trx=$(grep -c -E "^#!" "/etc/xray/config.json")
let trb=$trx/2
clear
clear
line_atas
purple "       •••• Xray Trojan Menu •••• "
line_bawah
line_atas
echo -e " ${g}│  ${gb}[1]• ${b} Create Trojan Account "
echo -e " ${g}│  ${gb}[2]• ${b} Renewal Trojan Account "
echo -e " ${g}│  ${gb}[3]• ${b} Delete Trojan Account "
echo -e " ${g}│  ${gb}[4]• ${b} Check Trojan User Login"
echo -e " ${g}│  ${gb}[5]• ${b} Check Trojan User Account "
line_bawah
line_atas
echo -e " ${g}│  ${gb}[0]• ${b} Go Back To Menu"
line_bawah
echo -e ""
line_atas
red "    Xray Trojan Accounts : ${blue}$trb USER \e[0m"
line_bawah
echo -e ""
read -p " Select menu : " opt
echo -e ""
case $opt in
1) clear ; add-tr ;;
2) clear ; renew-tr ;;
3) clear ; del-tr ;;
4) clear ; cek-tr ;;
5) clear ; log-trojan ;;
6) clear ; usgtrojan ;;
0) clear ; menu ;;
x) exit ;;
*) m-trojan ;;
esac
