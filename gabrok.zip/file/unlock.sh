#!/bin/bash
# Color Type 9
CY="\e[96;1m" # Cyan
CyanBee="\e[5;36m" # BlueCyan
GreenBe="\e[5;32m" # Green / hijau
WhiteBe="\e[5;37m" # White / Putih
Green="\e[92;1m"
GREEN="\e[92;1m"
RED="\e[91;1m"
# Color type 38
LO='\e[38;5;162m'
UK='\033[5;36m'  # UNGU KOLOT
BK='\e[38;5;196m' # BEREM KOLOT 
R1='\e[38;5;155m' # HEJO SEMU BODAS
R2='\e[38;5;49m'  # HEJO LIME / APEL
BC='\e[38;5;195m' # BODAS CERAH PISAN
HU='\e[38;5;115m' # HEJO SEMU ABU
UB='\e[38;5;147m' # UNGU KABODASAN
KT='\e[38;5;187m' # KONENG TARIGU
Suffix='\e[0m'

# . Liner L1
function L1() {
  echo -e "${UK}┌──────────────────────────────────────────┐ ${Suffix} "
}


# . Liner L2
function L2() {
  echo -e "${UK}└──────────────────────────────────────────┘ ${Suffix}"
}


# . Liner Horizontal
function Horizontal(){
  echo -e "${UK}———————————————————————————————————————————      ${Suffix}"
}

  
  # // Lunatic Backend Banner
function Lunatic_Banner() {
clear
L1
echo -e "${CyanBee}             SEKENCOIS X CODE                  ${Suffix}"
L2
}

  # // Thanks To SEKENCOIS X CODE
function Sc_Credit(){
sleep 2
L1
echo -e "${CyanBee}       Terimakasih Telah Menggunakan-      ${Suffix}"
echo -e "${CyanBee}                Script Credit              ${Suffix}"
echo -e "${CyanBee}              SEKENCOIS X CODE            ${Suffix}"
L2
read -p "[Enter] Back Menu "
menu
}

function ENVIRONMENT() {
L1
 echo -e "${R2}           ---[ UNLOCKED ]---             ${Suffix}"
L2
}

# // Submit Loading : sleep 3 & loading $!
function loading() {
clear
echo
echo
echo
  local pid=$1
  local delay=0.1
  local spin='-\|/'

  while ps -p $pid > /dev/null; do
    local temp=${spin#?}
    printf "[%c] " "$spin"
    local spin=$temp${spin%"$temp"}
    sleep $delay
    printf "\b\b\b\b\b\b"
  done

  printf "    \b\b\b\b"
}

function Format_Just_Input() {
Lunatic_Banner
L1
echo ""
echo -e "${GreenBe} Just Input a number ${Suffix}"
echo -e "${WhiteBe} Format Number in day${Suffix}"
echo -e ""
echo -e "${CyanBee} 1 = 1 day ${Suffix}"
echo -e "${CyanBee} 2 = 2 day ${Suffix}"
echo ""
L2
echo ""
}



clear
echo -e "${UK}┌──────────────────────────────────────────┐${Suffix}"
echo -e "${BC}   USERNAME       EXP DATE         STATUS       ${Suffix}"
echo -e "${UK}└──────────────────────────────────────────┘${Suffix}"
echo -e "${UK}┌──────────────────────────────────────────┐${Suffix}"

while read expired
do
AKUN="$(echo $expired | cut -d: -f1)"
ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
status="$(passwd -S $AKUN | awk '{print $2}' )"
if [[ $ID -ge 1000 ]]; then
if [[ "$status" = "L" ]]; then
 printf "%-17s %2s %-17s %2s \n" "  $AKUN" "$exp   " "LOCKED${NORMAL}"
else
 printf "%-17s %2s %-17s %2s \n" "  $AKUN" "$exp   " "UNLOCKED${NORMAL}"
fi
fi
done < /etc/passwd
JUMLAH="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"

echo -e "${UK}└──────────────────────────────────────────┘${Suffix}"
echo -e "${UK}┌──────────────────────────────────────────┐${Suffix}"
echo -e "${R2}   Account number: $JUMLAH   user                 ${Suffix}"
echo -e "${UK}└──────────────────────────────────────────┘${Suffix}"
echo " "
echo " "
read -p "Input Username To Unlock :   " username

sleep 3 & loading $!

egrep "^$username" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
# proses mengganti passwordnya
passwd -u $username

# // Frint Succes
  Lunatic_Banner
  Horizontal
  echo ""
  echo -e "${GreenBe} successfully ${Suffix}"
  echo ""
  echo -e "${R2} Username  : $username${Suffix}"
  echo -e "${R2} Status    : Unlock ${Suffix} "
  echo ""
  Horizontal
  Sc_Credit

# // Frint Wrong !! 
else
Lunatic_Banner
Horizontal
echo ""
echo -e "${BK} Invallid ${Suffix}"
echo ""
echo -e "${BC} Username  : $username ${Suffix}"
echo -e "${BC} List user : Empty ${Suffix}"
echo ""
Horizontal
Sc_Credit
fi
menu