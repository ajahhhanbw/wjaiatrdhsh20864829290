#!/bin/bash
clear
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
######################################

# // ───>>> BACKGROUND

BG_GRN="\033[42;1m" # BG HIJAU
BG_RED="\033[45;1m" # BG MERAH
BG_CYN="\033[46;1m" # BG CYANN
BG_BLU="\033[44;1m" # BG BIRU
BG_PUR="\033[43;1m" # BG KUNING
BG_YEL="\033[93;1m" # BG konengWaduk
BG_WHT="\033[47;1m" # BG PUTIH
BG_RED="\033[41;97;1m" # BG MERAH
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
clear
domen=`cat /etc/xray/domain`
ISP=$(cat /usr/local/etc/xray/org)
CITY=$(cat /usr/local/etc/xray/city)
    echo -e "${BLUE}┌━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┐\033[0m"
    echo -e "  ${CYAN}            PANEL SSH  ACCOUNT             \E[0m"
    echo -e "${BLUE}└━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┘\033[0m"

read -p "Username : " Login
read -p "Password : " Pass
read -p "Expired (hari): " masaaktif

IP=$(curl -sS ifconfig.me);

sleep 1
clear
useradd -e `date -d "$masaaktif days" +"%Y-%m-%d"` -s /bin/false -M $Login
exp="$(chage -l $Login | grep "Account expires" | awk -F": " '{print $2}')"
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null
PID=`ps -ef |grep -v grep | grep sshws |awk '{print $2}'`

if [[ ! -z "${PID}" ]]; then
echo -e " \E[0;33;44;1m    SSH Account Detail    \E[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "${RED}------------------------------------------------------\033[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Username    : $Login" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Password    : $Pass" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "${BLUE} ------------------------------------------------------\033[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "IP          : $IP" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Host        : $domen" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "ISP         : $ISP" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "OpenSSH     : 22" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Dropbear    : 109, 69, 143" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "SSH WS      : 80, 8880, 8080, 2082, 2095" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "SSH SSL WS  : 443, 8443, 2083, 2053, 2096" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "SSL/TLS     : 222, 777" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "UDPGW       : 7100-7900" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "${RED} ------------------------------------------------------\033[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Expired On     : $exp" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "${BLUE} ------------------------------------------------------\033[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
else
echo -e " \E[0;33;44;1m   SSH Account Detail    \E[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "${BLUE}------------------------------------------------------\033[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Username    : $Login" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Password    : $Pass" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "${RED} ------------------------------------------------------\033[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "IP          : $IP" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Host        : $domen" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "ISP         : $ISP" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "OpenSSH     : 22" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Dropbear    : 109, 69, 143" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "SSH WS      : 80, 8880, 8080, 2082, 2095" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "SSH SSL WS  : 443, 8443, 2083, 2053, 2096" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "SSL/TLS     : 222, 777" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "UDPGW       : 7100-7900" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "${BLUE} ------------------------------------------------------\033[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "Expired On     : $exp" | tee -a /etc/xraylog/log-ssh-$Login.txt
echo -e "${RED} ------------------------------------------------------\033[0m" | tee -a /etc/xraylog/log-ssh-$Login.txt
ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-10)
CITY=$(wget -qO- ipinfo.io/city)
TIME=$(date +'%Y-%m-%d %H:%M:%S')
TIMES="10"
CHATID="-1002100547917"
KEY="6761427805:AAFuwglpszmsioSVrj6MHhYGMBqX2IHqXdE"
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT="
<code>•──────────────────•</code>
<b>  👾 New Transaction 👾      </b>
<code>•──────────────────•</code>
<code>ISP      : $ISP</code>
<code>CITY     : $CITY</code>
<code>DOMAIN   : $domen</code>
<code>DATE     : $TIME</code>
<code>DETAIL   : Ssh Account</code>
<code>DURASI   : $masaaktif Day</code>
<code>•──────────────────•</code>
<i>✨ Thank you $Login for order ✨</i>
"
curl -s --max-time $TIMES -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
fi
echo "" | tee -a /etc/xraylog/log-ssh-$Login.txt
read -n 1 -s -r -p "Press any key to back"
m-sshovpn

