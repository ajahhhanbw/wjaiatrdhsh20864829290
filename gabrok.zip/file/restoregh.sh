#!/bin/bash
# Provide by xlrd × dimz
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
g="\033[1;93m"
gb="\e[92;1m"
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
clear
line_atas
purple "     •••• RESTORE VIA LINK GITHUB ••••          \E[0m"
line_bawah
echo ""
red " Pastikan link backup hanya dibuat dari Autoscript ini Saja !"
red " Link backup via github only"
echo "Please paste the link here"
echo -e ""
read -rp "Link File: " -e url
wget -O backup.zip "$url"
unzip backup.zip
rm -f backup.zip
clear
clear
clear
rm -f /root/backup/backup.zip &> /dev/null
clear
echo -e "${PURPLE}┌────────────────────────────────────────────┐${NC}"

cd /root/backup
echo -e "${PURPLE}│${NC}  [ ${BLUE}INFO${NC} ] • Restoring passwd data..."
sleep 1
cp /root/backup/passwd /etc/ &> /dev/null
echo -e "${PURPLE}│${NC}  [ ${BLUE}INFO${NC} ] • Restoring group data..."
sleep 1
cp /root/backup/group /etc/ &> /dev/null
echo -e "${PURPLE}│${NC}  [ ${BLUE}INFO${NC} ] • Restoring shadow data..."
sleep 1
cp /root/backup/shadow /etc/ &> /dev/null
echo -e "${PURPLE}│${NC}  [ ${BLUE}INFO${NC} ] • Restoring gshadow data..."
sleep 1
cp /root/backup/gshadow /etc/ &> /dev/null
echo -e "${PURPLE}│${NC}  [ ${BLUE}INFO${NC} ] • Restoring chap-secrets data..."
sleep 1
cp /root/backup/chap-secrets /etc/ppp/ &> /dev/null
echo -e "${PURPLE}│${NC}  [ ${BLUE}INFO${NC} ] • Restoring admin data..."
echo -e "${PURPLE}└────────────────────────────────────────────┘${NC}"
cp -r /root/backup/xlordhost /var/lib/ &> /dev/null
cp -r /root/backup/.acme.sh /root/ &> /dev/null
cp -r /root/backup/xray /etc/ &> /dev/null
cp -r /root/backup/public_html /home/vps/ &> /dev/null
cp -r /root/backup/crontab /etc/ &> /dev/null
cp -r /root/backup/cron.d /etc/ &> /dev/null
cp -r /root/backup/xraylog /etc/ &> /dev/null
cp -r /root/backup/lmt /etc/ &> /dev/null
cp -r /root/backup/usg /etc/ &> /dev/null
cp -r /root/backup/client /etc/ &> /dev/null
rm -rf /root/backup &> /dev/null
rm -f /root/backup/backup.zip &> /dev/null
echo -e " [ ${BLUE}INFO${NC} ] • Restore Success"
sleep 0.5
red "Reboot Setelah backup...."
sleep 0.5
echo "Reboot in 5 Detik"
sleep 5
red "Rebooting..."
sleep 0.5
reboot