#!/bin/bash
echo 1 > /proc/sys/vm/drop_caches

